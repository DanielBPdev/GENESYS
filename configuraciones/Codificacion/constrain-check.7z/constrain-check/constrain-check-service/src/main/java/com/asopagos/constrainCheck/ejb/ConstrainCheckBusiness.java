package com.asopagos.constrainCheck.ejb;

import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.Properties;

import javax.ejb.Stateless;
import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Table;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;

import com.asopagos.constrainCheck.service.ConstrainCheckService;
import com.asopagos.enumeraciones.personas.EstadoAportesEmpleadorEnum;

/**
 * <b>Descripcion:</b> Clase que <br/>
 * que generar los alter table para los constrain check <b>Módulo:</b> Asopagos
 * - HU <br/>
 * m 66-92-93-70
 *
 * @author Jhonnatan Orozco Duque
 *         <a href="mailto:jorozco@heinsohn.com.co"> jorozco@heinsohn.com.co
 *         </a>
 */
@Stateless
public class ConstrainCheckBusiness implements ConstrainCheckService {

	/**
	 * Referencia a la unidad de persistencia
	 */

	@PersistenceContext(unitName = "constrainCheck_PU")
	private EntityManager entityManager;

	/**
	 * Referencia al logger
	 */
	// private static final ILogger logger =
	// LogManager.getLogger(ConstrainCheckBusiness.class);

	/**
	 * Metodo que genera el archivo de alter para las constrains checks
	 */
	public String generarConstrainCheck() {

		// try {

		StringBuilder sbFinal = new StringBuilder();
		Metamodel meta = entityManager.getMetamodel();
		for (EntityType<?> eachEntity : meta.getEntities()) {
			Class<?> entityClass = eachEntity.getJavaType();
			String entityTableName = entityClass.getAnnotation(Table.class).name();
			System.out.println("\n\t" + entityTableName);


			for (Field eachAttribute : entityClass.getDeclaredFields()) {
				
				if (eachAttribute.getType().isEnum()) {
					StringBuilder sbAlterTable = new StringBuilder();
					String	valuesEnum ="";
					String columName = eachAttribute.getAnnotation(Column.class).name();
					sbAlterTable.append("ALTER TABLE ").append(entityTableName).append(" ADD CONSTRAINT CK_")
					.append(entityTableName).append(columName).append(" CHECK (").append(columName).append(" IN (");
					for (Object eachEnumValue : eachAttribute.getType().getEnumConstants()) {
						valuesEnum = sbAlterTable.append("'").append(eachEnumValue).append("',").toString();
						
					}
					
					String finalValuesEnum = valuesEnum.substring(0, valuesEnum.length()-1); 
					sbFinal.append(finalValuesEnum).append("));").append("\n\t");
					
				}
				
			}
			try{
			Properties propiedades = new Properties();
		    String nomArchivo = "check_constrain.sql";

		    
		    	
		      FileWriter fichero = new FileWriter(("F:\\")+ nomArchivo);

		      //Inserto los alter table
		      fichero.write(sbFinal.toString());

		      fichero.close();

		    }catch(Exception ex){
		      ex.printStackTrace();
		    }
			
		}

		return "ok";

	

	}

	
}
