package com.asopagos.constrainCheck.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 * <b>Descripción:</b> Interface que define los métodos de negocio relacionados con la gestión de empleadores <b>Módulo:</b> Asopagos -
 * transversal<br/>
 * <b>Módulo:</b> Asopagos - HU <br/>
 *
 * @author Jhonnatan Orozco Duque <a href="jorozco:jorozco@heinsohn.com.co"> jorozco</a>
 *
 */
@Path("constrain-check")
@Consumes("application/json; charset=UTF-8")
@Produces("application/json; charset=UTF-8")
public interface ConstrainCheckService {

	/**
     * <b>Descripcion</b>Metodo que se encarga de consultar los alter table que se deben realizar para hacer las constrain check
     *
     * @return retorna Un string con los alter table
     *
     */
    @GET
    public String generarConstrainCheck();
	
}
