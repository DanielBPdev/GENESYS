((params) => {
  
  const readEmail = () => {
    const redirectUri = new URLSearchParams(params).get(
      "redirect_uri"
    );
    const email = redirectUri.split('email=')[1];
    if (!email) {
      return;
    } else {
      const password = document.getElementById("password");
      const username = document.getElementById("username");
      username.setAttribute("value", email);
      password.focus();
    }
  }

  window.addEventListener("DOMContentLoaded", () => readEmail());

})(window.location.search);
